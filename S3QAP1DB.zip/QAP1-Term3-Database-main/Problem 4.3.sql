
INSERT INTO authors (first_name, last_name, birth_date, country)
VALUES ('John', 'Doe', '1980-01-15', 'USA'),
       ('Alice', 'Smith', '1975-03-22', 'Canada');


INSERT INTO "Books" (title, publication_date, author_id)
VALUES ('Book 1', '2022-05-10', 1),
       ('Book 2', '2021-08-15', 1),
       ('Book 3', '2023-02-28', 2);
